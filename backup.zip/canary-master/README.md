# SeedBot [Canary]

[![Maintainability](https://api.codeclimate.com/v1/badges/64a6a96a1e3e6d3ed795/maintainability)](https://codeclimate.com/github/discordseedbot/canary/maintainability)
