require('./main.js').cmd();
