require("./main.js").init();
