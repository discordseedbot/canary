console.log("Youtube Standalone Started");
require('./main.js').init();